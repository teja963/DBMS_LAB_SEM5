my ports in the system are different so i had to config them and do, but then even after doing
that and setting a database the html file is showing my php when submitted my system settings needs to be changed but i have to reboot if i do so
i'm helpless i've tried every possible way that i could find but it's of no use please help me with this problem. 